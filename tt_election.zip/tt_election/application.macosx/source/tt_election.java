import processing.core.*; 
import processing.data.*; 
import processing.opengl.*; 

import controlP5.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class tt_election extends PApplet {



/** MAS S60 Election Visualization
 *  Tiffany Tseng
 *  Description: Each state is represented by a colored ball, whose color value is scaled based on how red/blue the state voted
 *  The size of the ball represents the total number of voters
 *  Mouse over a ball to see more information about the state
 *  Based on this code: http://processing.org/learning/topics/bouncybubbles.html
 *  Last Updated: 11/27/12
 */

final int screenWidth = 800;
final int screenHeight = 800;
final int numStates = 43;
int Red, Blue;
int gradientWidth = 20;
int gradientHeight = 300;

boolean ballSelected = false;
String selectedState;

//bounciness variables
float spring = 0.5f;
float gravity = 0;
float friction = -0.6f;
Ball[] balls = new Ball[numStates];

final int minTotal = 212930; //minimum number of voters
final int maxTotal = 10288172; //maximum number of voters

PFont font;
ElectionData data;
String[] statePostalCodes;  // holds a list of state postal codes

ControlP5 cp5;
Slider chaos;

public void setup() {
  background(255);
  size(screenWidth, screenHeight);
  font = createFont("Arial",36,true);
  
  //load data
  data = new ElectionData(loadStrings("data/2012_US_election_state.csv"));
  statePostalCodes = data.getAllStatePostalCodes();

  Red = color(255, 0, 0);
  Blue = color(0, 10, 255);
  
  cp5 = new ControlP5(this);
  
  //add horizontal slider
  cp5.addSlider("chaos")
    .setPosition(50, 50)
    .setRange(0,100)
    .setValue(25)
    .setWidth(200)
    .setHeight(30)
    ;
  
  //initiate all balls
  for (int i = 0; i<numStates; i++){
    String currentPostalCode = statePostalCodes[i];
    StateData state = data.getState(currentPostalCode);
    
    //draw ball in random location
    int stateTotal = state.total;
    float ballSize = map(stateTotal, minTotal, maxTotal, 25, 100); //scale ball size based on total # of votes
    float colorCode = map(Math.round(state.pctForObama), 0, 100, 0, 1); //map color based on # of votes for obama
    int stateFill = lerpColor(Red, Blue, colorCode); 
    balls[i] = new Ball(random(0, screenWidth), random(0, screenHeight), ballSize, i, balls, stateFill, currentPostalCode);
  }  
}


public void draw() {
  background(0);
  
  for (int i =0; i<numStates; i++){
    balls[i].collide();
    balls[i].move();
    balls[i].display();
  }
  
  //draw rectangle containing state information
  rectMode(CENTER);
  fill(100, 128);
  noStroke();
  rect(width-200, height/2, 300, 200);
  
  if(ballSelected){
     textFont(font, 36);
     textAlign(CENTER);
     fill(255);
     
     //draw state name
     text(selectedState, width-200, height/2-20);
     
     StateData state = data.getState(selectedState);
     
     //draw state obama percentage
     fill(Blue);
     textSize(20);
     text(nf(Math.round(state.pctForObama),1,1)+ "%", width-200-40, height/2+20);
     fill(Red);
     text(nf(Math.round(state.pctForRomney),1,1)+ "%", width-200+40, height/2+20); 
  }
  else{
    fill(255);
    textSize(25);
    textAlign(CENTER);
    text("mouse over a ball", width-200, height/2);
  }
    
}
class Ball {
  float x, y;
  float diameter;
  float vx = 0;
  float vy = 0;
  int id;
  int ballFill;
  String state;
  Ball[] others;

  Ball(float xin, float yin, float din, int idin, Ball[] oin, int Fill, String ballState) {
    x = xin;
    y = yin;
    diameter = din;
    id = idin;
    others = oin;
    ballFill = Fill;
    state = ballState;
    
  } 

  public void collide() {
    for (int i = id + 1; i < numStates; i++) {
      float dx = others[i].x - x;
      float dy = others[i].y - y;
      float distance = sqrt(dx*dx + dy*dy);
      float minDist = others[i].diameter/2 + diameter/2;
      if (distance < minDist) { 
        float angle = atan2(dy, dx);
        float targetX = x + cos(angle) * minDist;
        float targetY = y + sin(angle) * minDist;
        float ax = (targetX - others[i].x) * spring;
        float ay = (targetY - others[i].y) * spring;
        vx -= ax;
        vy -= ay;
        others[i].vx += ax;
        others[i].vy += ay;
      }
    }
  }

  public void move() {
    vy += gravity;
    x += vx;
    y += vy;
    if (x + diameter/2 > width) {
      x = width - diameter/2;
      vx *= friction;
    }
    else if (x - diameter/2 < 0) {
      x = diameter/2;
      vx *= friction;
    }
    if (y + diameter/2 > height) {
      y = height - diameter/2;
      vy *= friction;
    } 
    else if (y - diameter/2 < 0) {
      y = diameter/2;
      vy *= friction;
    }
  }

  public void display() {
    fill(ballFill);
    if (mouseX > x - diameter/2 && mouseX < x + diameter/2 &&
      mouseY > y - diameter/2 && mouseY < y + diameter/2) {
        ballSelected = true;
        selectedState = state;
      }
    if(state == selectedState){
        stroke(255);
        strokeWeight(5);
      }
    else {
      noStroke();
    }
    ellipse(x, y, diameter, diameter);
  }
  
}

public void chaos(float chaosValue){
  spring=map(chaosValue, 0, 100, 0, 2.0f);
}
  
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "tt_election" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
